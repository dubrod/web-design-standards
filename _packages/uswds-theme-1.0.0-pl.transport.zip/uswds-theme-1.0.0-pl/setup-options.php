<?php

$output = 'After installation, Visit https://playbook.cio.gov/designstandards/ for framework documentation.
<br />
<label for="install_resources">Install sample content:</label>
<select name="install_resources" id="install_resources">
    <option value="">No</option>
    <option value="yes">Yes</option>
</select>';

return $output;
