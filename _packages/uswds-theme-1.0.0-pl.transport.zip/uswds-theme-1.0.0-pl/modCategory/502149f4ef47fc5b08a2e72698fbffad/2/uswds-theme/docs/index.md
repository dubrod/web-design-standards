# U.S. Web Design Standards Theme

MODX 2.4 Theme with nearly every layout combination possible in the MXT Theme Framework. Using the U.S. Web Design Standards.
